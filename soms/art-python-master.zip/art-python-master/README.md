# art-python
Adaptive Resonance Theory (ART) was developed by Stephen Grossberg and Gail Carpenter.  

# Documentation
See documentation [here](http://art-python.readthedocs.io/en/latest)
