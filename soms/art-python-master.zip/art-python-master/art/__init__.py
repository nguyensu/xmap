from art import train
from art import test

__version__ = '0.1.0'

__copyright__ = """Copyright 2017 C Birk Jones."""

__license__ = "Revised BSD License"