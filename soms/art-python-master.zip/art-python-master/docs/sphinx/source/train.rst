Training Code
=============

The training code includes the following class and functions:

.. automodule:: train
	:members:
	


